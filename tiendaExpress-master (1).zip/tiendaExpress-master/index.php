<?php

require_once "controladores/plantilla.controlador.php";

$plantilla = new PlantillaControlador();
$plantilla -> CargarPlantilla();